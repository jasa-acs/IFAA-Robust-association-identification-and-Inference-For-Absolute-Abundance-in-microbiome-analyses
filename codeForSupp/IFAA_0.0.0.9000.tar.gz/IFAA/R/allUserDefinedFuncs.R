##' @export

allUserFunc=function(){
  return(c("dataRecovTrans", "AIcalcu","metaData",
           "dataSparsCheck","dataInfo","runGlmnet",
           "cvPicasso","runPicasso","groupBetaToFullBeta"))
}